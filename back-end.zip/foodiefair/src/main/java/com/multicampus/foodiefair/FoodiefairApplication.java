package com.multicampus.foodiefair;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodiefairApplication {

    public static void main(String[] args) {
        SpringApplication.run(FoodiefairApplication.class, args);
    }

}
